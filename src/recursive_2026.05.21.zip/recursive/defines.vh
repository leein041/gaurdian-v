`ifndef DEFINES_VH
`define DEFINES_VH

//`define DEBUG_MODE  
`define 4_2_MODE
//`define 8_8_MODE
`define MAX2(A, B) (((A) > (B)) ? (A) : (B))
`endif 