`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/04/29 13:08:08
// Design Name: 
// Module Name: mac
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module mac_bal #(
    parameter WEIGHT_BITS = 16,
    parameter INPUT_BITS  = 16,
    parameter OUTPUT_BITS = 32 + 3
) (
    input                             i_clk,
    input                             i_rstn,
    input                             i_mac_en,
    // wgt
    input  signed [WEIGHT_BITS - 1:0] i_wgt_din,
    // ipt  
    input                             i_ipt_vld,
    input  signed [ INPUT_BITS - 1:0] i_ipt_din,
    // opt   
    output                            o_opt_vld,
    output signed [OUTPUT_BITS - 1:0] o_opt_dout
);
  // ====================== parmeter =======================  
  localparam SUM_CNT = 2;
  integer                         i;
  // ====================== wire ===========================

  wire signed [             47:0] w_mac_dat;
  // ====================== reg ============================ 
  reg                             r_opt_vld;
  reg         [$clog2(SUM_CNT):0] r_sum_cnt;
  reg signed  [             47:0] r_sum_dat;
  // ====================== hand shake ===================== 
  // ====================== always ========================= 
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      r_sum_cnt <= 'd0;
    end else if (i_ipt_vld) begin
      if (r_sum_cnt < SUM_CNT) r_sum_cnt <= r_sum_cnt + 'd1;
      else r_sum_cnt <= 'd0;
    end
  end
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      r_sum_dat <= 'd0;
    end else if (i_ipt_vld) begin
      if (r_sum_cnt != 'd0) r_sum_dat <= w_mac_dat;
      else r_sum_dat <= 'd0;
    end
  end
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      r_opt_vld <= 'b0;
    end else begin
      if (r_sum_cnt < SUM_CNT) r_opt_vld <= 'b0;
      else r_opt_vld <= 'b1;
    end
  end
  // ====================== module ========================= 
  dsp_mac_macro inst_mac (
      .CLK(i_clk),
      .CE (i_ipt_vld),
      .A  (i_ipt_din),
      .B  (i_wgt_din),
      .C  (r_sum_dat),
      .P  (w_mac_dat)
  );
  assign o_opt_vld  = r_opt_vld;
  assign o_opt_dout = w_mac_dat[OUTPUT_BITS-1 : 0];  // 32 + 3 (add 로 인한 3비트 확장) 
endmodule
