`timescale 1ns / 1ps

module patch_bal #(
    parameter INPUT_BITS   = 16,
    parameter PATCH_WIDTH  = 3,
    parameter PATCH_HEIGHT = 3,
    parameter LINE_WIDTH   = 5,
    parameter LINE_HEIGHT  = 3,

    localparam PATCH_SIZE = INPUT_BITS * PATCH_WIDTH * PATCH_HEIGHT
) (
    input                                i_clk,
    input                                i_rstn,
    input                                i_clr,
    // ipt
    input  [INPUT_BITS*PATCH_HEIGHT-1:0] i_ipt_din,
    input                                i_ipt_vld,
    output                               o_ipt_rdy,
    // opt
    input                                i_opt_rdy,
    output                               o_opt_vld,
    output [INPUT_BITS*PATCH_HEIGHT-1:0] o_opt_dout
);
  // ====================== parmeter =======================  
  localparam STATE_INPUT = 1'b0;
  localparam STATE_OUTPUT = 1'b1;
  genvar g;
  integer i, j;

  // ====================== wire ===========================

  wire w_act_in = o_ipt_rdy && i_ipt_vld;
  wire w_act_out = i_opt_rdy && o_opt_vld;

  // ====================== reg ============================ 
  reg r_cstat;
  reg r_nstat;
  reg signed [INPUT_BITS-1:0] r_ptch_dat[0:PATCH_HEIGHT-1][0:PATCH_WIDTH-1];
  reg [$clog2(PATCH_WIDTH)-1:0] r_pcol_cnt;
  reg [$clog2(  PATCH_WIDTH):0] r_fill_cnt;
  reg [$clog2(LINE_WIDTH)-1:0] r_lcol_cnt;
  reg [$clog2(LINE_HEIGHT)-1:0] r_prow_0, r_prow_1, r_prow_2;

  // ====================== hand shake ===================== 

  assign o_ipt_rdy = (r_cstat == STATE_INPUT);
  assign o_opt_vld = (r_cstat == STATE_OUTPUT);

  // ====================== FSM ============================    
  //  initialize
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) r_cstat <= STATE_INPUT;
    else if (i_clr) r_cstat <= STATE_INPUT;
    else r_cstat <= r_nstat;

  end
  // compute next state 
  always @(*) begin
    r_nstat = r_cstat;
    case (r_cstat)
      STATE_INPUT: if (r_fill_cnt == PATCH_WIDTH - 1) r_nstat = STATE_OUTPUT;
      STATE_OUTPUT: if (r_pcol_cnt == PATCH_WIDTH - 1) r_nstat = STATE_INPUT;
      default: ;
    endcase
  end
  //  compute RTL operations
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      r_pcol_cnt <= 'd0;
      r_fill_cnt <= 'd0;
    end else if (i_clr) begin
      r_pcol_cnt <= 'd0;
      r_fill_cnt <= 'd0;
    end else begin
      case (r_cstat)
        STATE_INPUT: begin
          if (w_act_in) begin
            if (r_fill_cnt < PATCH_WIDTH - 1) begin
              r_fill_cnt <= r_fill_cnt + 1'b1;
            end
          end
        end
        STATE_OUTPUT: begin
          if (w_act_out) begin
            if (r_pcol_cnt < PATCH_WIDTH - 1) begin
              r_pcol_cnt <= r_pcol_cnt + 1'b1;
            end else begin
              r_pcol_cnt <= 'd0;
              if (r_lcol_cnt == LINE_WIDTH) r_fill_cnt <= 'd0;
            end
          end
        end
      endcase
    end
  end
  // ====================== always ========================= 
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      r_lcol_cnt <= 'd0;
      r_prow_0   <= 'd0;
      r_prow_1   <= 'd1;
      r_prow_2   <= 'd2;
    end else begin
      if (i_clr) begin
        r_lcol_cnt <= 'd0;
        r_prow_0   <= 'd0;
        r_prow_1   <= 'd1;
        r_prow_2   <= 'd2;
      end else if (w_act_in) begin
        if (r_lcol_cnt < LINE_WIDTH) begin
          r_lcol_cnt <= r_lcol_cnt + 'd1;
        end else begin
          // 왜 1인가?
          // 초기화는 패치에 어떤 데이터가 없었으므로 카운트가 0
          // 다음 행으로 넘어갈 때에는 이미 데이터가 하나 들어온 것이므로 1
          r_lcol_cnt <= 'd1;
          r_prow_0   <= r_prow_2;
          r_prow_1   <= r_prow_0;
          r_prow_2   <= r_prow_1;
        end
      end
    end
  end

  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      for (i = 0; i < PATCH_HEIGHT; i = i + 1) begin
        for (j = 0; j < PATCH_WIDTH; j = j + 1) begin
          r_ptch_dat[i][j] <= 'd0;
        end
      end
    end else begin
      if (w_act_in) begin
        for (i = 0; i < PATCH_HEIGHT; i = i + 1) begin
          for (j = 0; j < PATCH_WIDTH - 1; j = j + 1) begin
            r_ptch_dat[i][j] <= r_ptch_dat[i][j+1];
          end
        end

        r_ptch_dat[r_prow_0][PATCH_WIDTH-1] <= i_ipt_din[0*INPUT_BITS+:INPUT_BITS];
        r_ptch_dat[r_prow_1][PATCH_WIDTH-1] <= i_ipt_din[1*INPUT_BITS+:INPUT_BITS];
        r_ptch_dat[r_prow_2][PATCH_WIDTH-1] <= i_ipt_din[2*INPUT_BITS+:INPUT_BITS];
      end
    end
  end

  // ====================== output ========================= 
  generate
    for (g = 0; g < PATCH_HEIGHT; g = g + 1) begin
      assign o_opt_dout[g*INPUT_BITS+:INPUT_BITS] = r_ptch_dat[g][r_pcol_cnt];
    end
  endgenerate

endmodule
