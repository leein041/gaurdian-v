`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/04/23 16:06:57
// Design Name: 
// Module Name: PU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// 3 mac * 3 times compute
module pu_bal #(
    parameter WEIGHT_BITS  = 16,
    parameter INPUT_BITS   = 16,
    parameter OUTPUT_BITS  = 36,
    parameter PATCH_WIDTH  = 3,
    parameter PATCH_HEIGHT = 3,
    parameter LINE_WIDTH   = 5,
    parameter LINE_HEIGHT  = 3,

    localparam PATCH_AREA = PATCH_WIDTH * PATCH_HEIGHT,
    localparam PATCH_SIZE = INPUT_BITS * PATCH_AREA,

    localparam PE_OUTPUT_BIT = INPUT_BITS * 2 + 3,  // 35
    localparam MAT_OUTPUT_BIT = PE_OUTPUT_BIT + $clog2(PATCH_HEIGHT)
) (
    input                                           i_clk,
    input                                           i_rstn,
    input                                           i_clr,
    // wgt 
    input                                           i_wgt_vld,
    input  signed [               WEIGHT_BITS -1:0] i_wgt_din,
    // ipt
    output                                          o_ipt_rdy,
    input                                           i_ipt_vld,
    input  signed [INPUT_BITS * PATCH_HEIGHT - 1:0] i_ipt_din,
    // opt
    input                                           i_opt_rdy,
    output                                          o_opt_vld,
    output signed [           MAT_OUTPUT_BIT - 1:0] o_opt_dout
);
  // ------------------- parmeter -------------------      
  localparam PE_DLY = 3;
  integer i;
  genvar c, p;
  // --------------------- wire ---------------------   
  // patch  
  wire                                         w_ptch_vld;
  wire signed [                INPUT_BITS-1:0] w_ptch_dat     [0:PATCH_HEIGHT-1];
  wire        [  INPUT_BITS *PATCH_HEIGHT-1:0] w_ptch_dat_pck;
  // pe             
  wire                                         w_pe_act;
  wire        [              PATCH_HEIGHT-1:0] w_pe_vld;
  wire signed [             PE_OUTPUT_BIT-1:0] w_pe_dat       [0:PATCH_HEIGHT-1];
  wire        [PE_OUTPUT_BIT*PATCH_HEIGHT-1:0] w_pe_dat_pck;
  // mac at 
  wire                                         w_mat_rdy;
  // ====================== reg ============================ 
  reg         [        $clog2(PATCH_AREA)-1:0] r_wgt_cnt;
  reg signed  [               WEIGHT_BITS-1:0] r_wgt_dat      [  0:PATCH_AREA-1];

  // reg         [              $clog2(PE_DLY):0] r_pe_rdy;
// ====================== hand shake ===================== 
    
  assign w_pe_act = w_ptch_vld && w_mat_rdy;
// ====================== assign ========================= 
  // mat 
  // ====================== always ========================= 

  // initialize weight data
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      for (i = 0; i < PATCH_AREA; i = i + 1) begin
        r_wgt_dat[i] <= 'd0;
      end
    end else if (i_wgt_vld) begin
      for (i = 0; i < PATCH_AREA - 1; i = i + 1) begin
        r_wgt_dat[i] <= r_wgt_dat[i+1];
      end
      r_wgt_dat[PATCH_AREA-1] <= i_wgt_din;
    end
  end
  // weigt counter 
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      r_wgt_cnt <= 'd0;
    end else begin
      if (i_clr) begin
        r_wgt_cnt <= 'd0;
      end else if (w_pe_act) begin
        if (r_wgt_cnt < PATCH_WIDTH - 1) begin
          r_wgt_cnt <= r_wgt_cnt + 'd1;
        end else begin
          r_wgt_cnt <= 'd0;
        end
      end
    end
  end

  // ------------------- Unpack / Pack -------------------  
  generate
    for (p = 0; p < PATCH_HEIGHT; p = p + 1) begin
      // patch
      assign w_ptch_dat[p] = w_ptch_dat_pck[p*INPUT_BITS+:INPUT_BITS];
      // pe 
      assign w_pe_dat_pck[p*PE_OUTPUT_BIT+:PE_OUTPUT_BIT] = w_pe_dat[p];
    end
  endgenerate
// ====================== module ========================= 
  patch_bal #(
      .INPUT_BITS  (INPUT_BITS),
      .PATCH_WIDTH (PATCH_WIDTH),
      .PATCH_HEIGHT(PATCH_HEIGHT),
      .LINE_WIDTH  (LINE_WIDTH),
      .LINE_HEIGHT (LINE_HEIGHT)
  ) inst_patch_bal (
      .i_clk     (i_clk),
      .i_rstn    (i_rstn),
      .i_clr     (i_clr),
      // ipt
      .i_ipt_din (i_ipt_din),
      .i_ipt_vld (i_ipt_vld),
      .o_ipt_rdy (o_ipt_rdy),
      // opt
      .i_opt_rdy (w_mat_rdy),
      .o_opt_vld (w_ptch_vld),
      .o_opt_dout(w_ptch_dat_pck)
  );
  generate
    for (p = 0; p < PATCH_HEIGHT; p = p + 1) begin : pe_array
      pe_bal #(
          .INPUT_BITS  (INPUT_BITS),
          .WEIGHT_BITS (WEIGHT_BITS),
          .OUTPUT_BITS (PE_OUTPUT_BIT),
          .PATCH_WIDTH (PATCH_WIDTH),
          .PATCH_HEIGHT(PATCH_HEIGHT)
      ) inst_pe_bal (
          .i_clk     (i_clk),
          .i_rstn    (i_rstn),
          .i_pe_en   (w_pe_act),
          // wgt 
          .i_wgt_din (r_wgt_dat[p*PATCH_WIDTH+r_wgt_cnt]),
          // ipt  
          .i_ipt_vld (w_ptch_vld),
          .i_ipt_din (w_ptch_dat[p]),
          // opt  
          .o_opt_vld (w_pe_vld[p]),
          .o_opt_dout(w_pe_dat[p])
      );
    end
  endgenerate
  adder_tree #(
      .INPUT_BIT(PE_OUTPUT_BIT),
      .INPUT_NUM(PATCH_HEIGHT)
  ) inst_pe_at (
      .i_clk     (i_clk),
      .i_rstn    (i_rstn),
      // ipt
      .o_ipt_rdy (w_mat_rdy),
      .i_ipt_vld (w_pe_vld),
      .i_ipt_din (w_pe_dat_pck),
      // opt
      .i_opt_rdy (i_opt_rdy),
      .o_opt_vld (o_opt_vld),
      .o_opt_dout(o_opt_dout)
  );
endmodule
