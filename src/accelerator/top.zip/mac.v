`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/04/29 13:08:08
// Design Name: 
// Module Name: mac
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

/* 
mac이 많아진다
-> 48비트 output register 가 많아진다
-> output register 는 타이밍 안정도를 높이기 위함임
-> 자원 제한적이면 output assign 으로 바로 출력  
-> delay 레지스터는 필수

*/

module mac #(
    parameter INPUT_BITS  = 16,
    parameter WEIGHT_BITS = 16,
    parameter OUTPUT_BITS = 48
) (
    input                             i_clk,
    input                             i_rstn,
    input                             i_en,
    input  signed [ INPUT_BITS - 1:0] i_input,
    input  signed [WEIGHT_BITS - 1:0] i_weight,
    output                            o_valid,
    output signed [OUTPUT_BITS - 1:0] o_data
);

  // wrie
  wire signed [OUTPUT_BITS - 1:0] r_dsp_output;

  // reg
  reg delay0;
  // reg r_valid;
  // reg r_data;

  //assign
  assign o_valid = (delay0);
  assign o_data  = r_dsp_output;

  // delay for mac calculate (add : 1  clock)
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      delay0 <= 'd0;
    end else begin
      delay0 <= i_en;
    end
  end

  // always @(posedge i_clk or negedge i_rstn) begin
  //   if (~i_rstn) begin
  //     r_valid <= 'd0;
  //     r_data  <= 'd0;
  //   end else begin
  //     r_valid <= 'd0;
  //     if (delay0) begin
  //       r_valid <= 'd1;
  //       r_data  <= r_dsp_output;
  //     end
  //   end
  // end

  dsp_add_macro dsp (
      .CLK(i_clk),
      .CE (1'b1),         // 저전력 설계시 off 고려
      .A  (i_input),
      .B  (i_weight),
      .P  (r_dsp_output)
  );

endmodule
