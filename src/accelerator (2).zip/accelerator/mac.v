`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/04/29 13:08:08
// Design Name: 
// Module Name: mac
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

/* 
  mac이 많아진다
  -> 48비트 output register 가 많아진다
  -> output register 는 타이밍 안정도를 높이기 위함임
  -> 자원 제한적이면 output assign 으로 바로 출력  
  -> delay 레지스터는 필수

  */

module mac #(
    parameter WEIGHT_BITS = 16,
    parameter INPUT_BITS  = 16,
    parameter OUTPUT_BITS = 32
) (
    input                             i_clk,
    input                             i_rstn,
    input                             i_mac_en,
    // wgt
    input  signed [WEIGHT_BITS - 1:0] i_wgt_din,
    // ipt 
    input                             i_ipt_vld,
    input  signed [ INPUT_BITS - 1:0] i_ipt_din,
    // opt 
    output                            o_opt_vld,
    output signed [OUTPUT_BITS - 1:0] o_opt_dout
);
  // ----------------------- parmeter ---------------------- 
  localparam DSP_DLY = 1;
  // ------------------------- wire ------------------------ 
  // ------------------------- reg -------------------------   
  // opt
  reg r_opt_vld; 
  // ---------------------- hand shake --------------------- 
  // ------------------------ assign -----------------------   
  assign o_opt_vld = r_opt_vld;
  // ------------------------ always ----------------------- 
  // output
  always @(posedge i_clk or negedge i_rstn) begin
    if (~i_rstn) begin
      r_opt_vld <= 'd0;
    end else begin
      r_opt_vld <= i_ipt_vld;  // 1 clock latency by DSP
    end
  end
  // ------------------------- module ----------------------  
  dsp_mul_macro dsp (
      .CLK(i_clk),
      .CE (i_mac_en),
      .A  (i_ipt_din),
      .B  (i_wgt_din),
      .P  (o_opt_dout)
  );

endmodule
